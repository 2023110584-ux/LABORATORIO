package com.demo;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DemoApplicationTests {
    @Test
    void basicTest() {
        assertTrue(2 + 2 == 4);
    }
}
